
// Author: Dimitri Reiswich

        InterestRate(Rate r,
                     const DayCounter& dc = Actual365Fixed(),
                     Compounding comp = Continuous,
                     Frequency freq = Annual);
