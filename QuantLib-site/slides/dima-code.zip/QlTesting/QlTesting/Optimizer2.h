
// Author: Dimitri Reiswich
        EndCriteria(Size maxIterations,
                    Size minStationaryStateIterations,
                    Real rootEpsilon,
                    Real functionEpsilon,
                    Real gradientNormEpsilon);