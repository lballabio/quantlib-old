
// Author: Dimitri Reiswich




Real exercise1(const Real& x){

	QL_REQUIRE(x!=0,"Dividing by zero in reciproke.");
	return 1.0/x;

}