
// Author: Dimitri Reiswich
		Real solve(const F& f,
                   Real accuracy,
                   Real guess,
                   Real step) 
                   
        Real solve(const F& f,
                   Real accuracy,
                   Real guess,
                   Real xMin,
                   Real xMax)
