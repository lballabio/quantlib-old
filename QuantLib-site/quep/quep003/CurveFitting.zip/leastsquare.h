// Emacs will be in -*- Mode: c++ -*-
//
// ************ DO NOT REMOVE THIS BANNER ****************
//
//  Nicolas Di Cesare <Nicolas.Dicesare@free.fr>
//  http://acm.emath.fr/~dicesare
//
//********************************************************
//
//  Least Square Method using conjugate gradient method
//
//********************************************************
#ifndef __leastsquare_h__
#define __leastsquare_h__

#include <cg.h>

/*!
  Base class for least square problem
  V is vector class and M a matrix class
*/
template <class V, class M>
class LeastSquareProblem {
public:
  //! size of the problem ie size of target vector
  virtual int size()  = 0;
  //! compute the target vector and the values of the fonction to fit
  virtual void targetAndValue(const V& x, V& target, V& fct2fit) = 0;
  //! compute the target vector, the values of the fonction to fit and the matrix of derivatives
  virtual void targetValueAndfirstDerivative(const V& x, M& grad_fct2fit, V& target, V& fct2fit) = 0;
};

/*!
  Design a least square function as a cost function using 
  the interface provided by LeastSquareProblem<V,M> class.
  V vector class requires function DotProduct() that computes dot product 
  and - operator
  M matrix class requires function transpose() that computes transpose
  and * operator with vector class  
*/
template <class V, class M>
class LeastSquareFunction : public CostFunction<V> {
public:
  //! value type of the vector
  typedef double value_type;
protected:
  //! least square problem
  LeastSquareProblem<V,M> & lsp_;
public:
  //! Default constructor
  LeastSquareFunction(LeastSquareProblem<V,M> & lsp) : lsp_(lsp) {}
  //! Destructor
  virtual ~LeastSquareFunction() {}
  
  //! compute value of the least square function
  virtual value_type value(const V& x);
  //! compute vector of derivatives of the least square function
  virtual void firstDerivative(V& grad_f, const V& x);
  //! compute value and vector of derivatives of the least square function
  virtual value_type valueAndFirstDerivative(V& grad_f, const V& x);
  
  //! to improve
  virtual void Update() {}
  //! to improve
  virtual void Save(OptimizationMethod<V>&) {}
};


template <class V, class M>
typename LeastSquareFunction<V,M>::value_type 
LeastSquareFunction<V,M>::value(const V& x) 
{
  // size of target and function to fit vectors
  V target(lsp_.size()), fct2fit(lsp_.size()); 
  // compute its values
  lsp_.targetAndValue(x,target,fct2fit);
  // do the difference 
  V diff = target - fct2fit;
  // and compute the scalar product (square of the norm)
  return DotProduct(diff,diff);
}

template <class V, class M>
void LeastSquareFunction<V,M>::firstDerivative(V& grad_f, const V& x)
{
  // size of target and function to fit vectors
  V target(lsp_.size()), fct2fit(lsp_.size()); 
  // size of gradient matrix
  M grad_fct2fit(lsp_.size(),x.size());
  // compute its values
  lsp_.targetValueAndfirstDerivative(x,grad_fct2fit,target,fct2fit);
  // do the difference 
  V diff = target - fct2fit;
  // compute derivative
  grad_f = -2.*(transpose(grad_fct2fit)*diff);
}

template <class V, class M>
typename LeastSquareFunction<V,M>::value_type 
LeastSquareFunction<V,M>::valueAndFirstDerivative(V& grad_f, const V& x) 
{
  // size of target and function to fit vectors
  V target(lsp_.size()), fct2fit(lsp_.size()); 
  // size of gradient matrix
  M grad_fct2fit(lsp_.size(),x.size());
  // compute its values
  lsp_.targetValueAndfirstDerivative(x,grad_fct2fit,target,fct2fit);
  // do the difference 
  V diff = target - fct2fit;
  // compute derivative
  grad_f = -2.*(transpose(grad_fct2fit)*diff);
  // and compute the scalar product (square of the norm)
  return DotProduct(diff,diff);
}



/*!
  Default least square method using a given 
  optimization algorithm (default is conjugate gradient).

  min { r(x) : x in R^n } 

  where r(x) = ||f(x)||^2 the euclidian norm of f(x)
  for some vector-valued function f from R^n to R^m
  f = (f1, ..., fm) with fi(x) = bi - phi(x,ti)
  where bi is the vector of target data and phi 
  is a scalar function.
      
  Assuming the differentiability of f, the gradient of r 
  is define by
  grad r(x) = f'(x)^t.f(x)

  V vector class has the requirement of the previous class
  Handle class is need to manage pointer to optimization method
*/
template <class V>
class NonLinearLeastSquare {
  //! solution vector
  V results_, initialValue_;
  //! least square residual norm
  double resnorm_;
  //! Exit flag of the optimization process
  int exitFlag_;
  //! required accuracy of the solver
  double accuracy_, bestAccuracy_;
  //! maximum and real number of iterations
  unsigned int maxIterations_, nbIterations_;
  //! Optimization method
  QuantLib::Handle< OptimizationMethod<V> > om_;
public:
  //! Default constructor
  inline NonLinearLeastSquare(double accuracy = 1e-4,
			      int maxiter = 100);
  //! Default constructor
  inline NonLinearLeastSquare(double accuracy,
			      int maxiter,
			      QuantLib::Handle< OptimizationMethod<V> > om);  
  //! Destructor
  inline ~NonLinearLeastSquare() {}

  //! Solve least square problem using numerix solver
  template <class M> inline 
  V& Perform(LeastSquareProblem<V,M> & lsProblem)
  {
    double eps = accuracy_;

    // set initial value of the optimization method
    om_->setInitialValue(initialValue_);
    // set end criteria with a given maximum number of iteration and a given error eps
    om_->setEndCriteria(OptimizationEndCriteria(maxIterations_, eps));
    om_->endCriteria().setPositiveOptimization();

    // wrap the least square problem in an optimization function
    LeastSquareFunction<V,M> lsf(lsProblem);

    // define optimization problem
    OptimizationProblem<V> P(lsf,*om_);

    // minimize
    P.Minimize();

    // summarize results of minimization
    exitFlag_ = om_->endCriteria().criteria();
    nbIterations_ = om_->iterationNumber();

    results_ = om_->x();
    resnorm_ = om_->functionValue();
    bestAccuracy_ = om_->functionValue();
  
    return results_;
  }

  inline void setInitialValue(const V& initialValue)
  { initialValue_ = initialValue;}

  //! return the results
  inline V& results() { return results_;}
  //! return the least square residual norm
  inline double residualNorm() { return resnorm_;}
  //! return last function value
  inline double lastValue() { return bestAccuracy_;}
  //! return exit flag
  inline int exitFlag() { return exitFlag_;}
  //! return the performed number of iterations
  inline int iterationsNumber() { return nbIterations_;}
};


template <class V> inline 
NonLinearLeastSquare<V>::NonLinearLeastSquare(double accuracy,
					      int maxiter)
  : exitFlag_(-1), accuracy_(accuracy), maxIterations_(maxiter), 
    om_(QuantLib::Handle< OptimizationMethod<V> >(new ConjugateGradient<V>()))
{}

template <class V> inline 
NonLinearLeastSquare<V>::NonLinearLeastSquare(double accuracy,
					      int maxiter,
					      QuantLib::Handle< OptimizationMethod<V> > om)
  : exitFlag_(-1), accuracy_(accuracy), maxIterations_(maxiter), om_(om)
{}


#endif
