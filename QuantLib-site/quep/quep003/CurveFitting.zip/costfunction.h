// Emacs will be in -*- Mode: c++ -*-
//
// ************ DO NOT REMOVE THIS BANNER ****************
//
//  Nicolas Di Cesare <Nicolas.Dicesare@free.fr>
//  http://acm.emath.fr/~dicesare
//
//********************************************************
//
//  Cost function abstract class
//
//********************************************************
#ifndef _costfunction_h
#define _costfunction_h

/*! 
  Cost function abstract class for unconstrained optimization pb
*/
template <class V>
class CostFunction {
public:
  typedef double value_type;

  //! method to overload to compute the cost functon value in x
  virtual value_type value(const V& x) = 0;

  //! method to overload to compute grad_f, the first derivative of the cost function with respect to x
  virtual void firstDerivative(V& grad_f, const V& x) // = 0;
  {
    value_type eps = finiteDifferenceEpsilon(), fp, fm;
    V xx = x;
    int i, sz = x.size();
    for (i=0; i<sz; ++i) {
      xx[i] += eps;
      fp = value(xx);
      xx[i] -= 2.*eps;
      fm = value(xx);
      grad_f[i] = 0.5*(fp - fm) / eps;
    }
  }// Default

  //! method to overload to compute grad_f, the first derivative of the cost function with respect to x and also the cost function
  virtual value_type valueAndFirstDerivative(V& grad_f, const V& x) 
  { firstDerivative(grad_f, x); return value(x);}// default case

  //! member to update things if required
  virtual void Update() {}

  //! Default epsilon for finite difference method : 
  virtual double finiteDifferenceEpsilon() { return 1e-8;}
};


#endif
