// Emacs will be in -*- Mode: c++ -*-
//
// ************ DO NOT REMOVE THIS BANNER ****************
//
//  Nicolas Di Cesare <Nicolas.Dicesare@free.fr>
//  http://acm.emath.fr/~dicesare
//
//********************************************************
//
//  portability file
//
//********************************************************
#ifndef __portability_h__
#define __portability_h__

#include <algorithm>
#include <numeric>
#include <cmath>


namespace portability {
#if !defined(_MSC_VER)||defined(__ICL)
	template <class Type> 
		Type min(const Type& x, const Type& y) 
			{ 
				Type min_;
				min_ = (x>y)? y:x;  
				return min_;
			}
	template <class Type> 
		Type max(const Type& x, const Type& y) 
			{
				Type max_;
				max_ = (x<y)? y:x;
				return max_;
			}
#endif
	template <class T> 
		T abs(const T& x) { return (x>0?x:-(x));}
}

// GNU C++ compiler
#ifdef __GNUG__
#define MIN(A,B) std::min(A,B)
#define MAX(A,B) std::max(A,B)
#define ABS(A) std::abs(A)
#define RESTRICT __restrict__
#endif
// MS Visual or Intel C++compiler
#if defined(_MSC_VER)
#define ABS(A) portability::abs(A)
#ifdef __ICL
#define MIN(A,B) portability::min(A,B)
#define MAX(A,B) portability::max(A,B)
#define RESTRICT restrict
#else
#define MIN(A,B) min(A,B)
#define MAX(A,B) max(A,B)
#define RESTRICT
#endif
#endif

/*
*/
#endif
