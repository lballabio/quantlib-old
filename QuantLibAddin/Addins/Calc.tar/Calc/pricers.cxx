#include "qluno.hxx"
//#include "utils.hpp"
//#include <string>
//#include <sstream>
//using std::ostringstream;
//using std::string;
#include "ObjectClassLibrary/ObjectOption.hpp"

extern ObjectHandler objectHandler;

SEQSEQ( double ) getArray(sal_Int32 r, sal_Int32 c, double *x) {
    SEQSEQ( double ) rows(r);
    for (int i = 0; i < r; i++) {
        SEQ( double ) row(c);
        for (int j = 0; j < c; j++) {
            row[j] = x[i * c + j];
        }
        rows[i] = row;
    }
    return rows;
}

SEQSEQ( double ) SAL_CALL QLUnoAddin::unoBlackScholes( 
		double dividendYield,
		double riskFreeRate,
		double volatility,
		double underlying,
		sal_Int32 todaysDateNum,
		sal_Int32 settlementDateNum) THROWDEF_RTE_IAE {
//	string handleStochastic = getCaller();
	string handleStochastic = "xxx";
	Date todaysDate(todaysDateNum);
	Date settlementDate(settlementDateNum);
	obj_ptr objectStochastic(
		new ObjectStochastic(dividendYield, riskFreeRate, volatility, 
			underlying, todaysDate, settlementDate));
	objectHandler.storeObject(handleStochastic, objectStochastic);
//	static XLOPER xRet;
//	setValues(&xRet, objectStochastic, handleStochastic);
//	return &xRet;
	double results[2];
	results[0] = 0.;
	results[1] = 1.;
	return getArray(2, 1, results);
}

/*
LPXLOPER QL_BLACKSCHOLES(
		double *dividendYield,
		double *riskFreeRate,
		double *volatility,
		double *underlying,
		long int *todaysDateNum,
		long int *settlementDateNum) {
	try {
		string handleStochastic = getCaller();
		Date todaysDate(*todaysDateNum);
		Date settlementDate(*settlementDateNum);
		obj_ptr objectStochastic(
			new ObjectStochastic(*dividendYield, *riskFreeRate, *volatility, 
				*underlying, todaysDate, settlementDate));
		objectHandler.storeObject(handleStochastic, objectStochastic);
		static XLOPER xRet;
		setValues(&xRet, objectStochastic, handleStochastic);
		return &xRet;
	} catch (const exception &e) {
		ostringstream msg;
		msg << "ERROR: QL_BLACKSCHOLES: " << e.what();
		logMessage(msg.str());
		return 0;
	}
}
*/
