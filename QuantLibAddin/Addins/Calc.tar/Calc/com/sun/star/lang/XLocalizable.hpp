#ifndef _COM_SUN_STAR_LANG_XLOCALIZABLE_HPP_
#define _COM_SUN_STAR_LANG_XLOCALIZABLE_HPP_

#ifndef _COM_SUN_STAR_LANG_XLOCALIZABLE_HDL_
#include <com/sun/star/lang/XLocalizable.hdl>
#endif

#ifndef _OSL_MUTEX_HXX_
#include <osl/mutex.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_TYPE_HXX_
#include <com/sun/star/uno/Type.hxx>
#endif
#ifndef _COM_SUN_STAR_UNO_REFERENCE_HXX_
#include <com/sun/star/uno/Reference.hxx>
#endif

#ifndef _COM_SUN_STAR_LANG_LOCALE_HPP_
#include <com/sun/star/lang/Locale.hpp>
#endif
#ifndef _COM_SUN_STAR_UNO_RUNTIMEEXCEPTION_HPP_
#include <com/sun/star/uno/RuntimeException.hpp>
#endif
#ifndef _COM_SUN_STAR_UNO_TYPECLASS_HPP_
#include <com/sun/star/uno/TypeClass.hpp>
#endif
#ifndef _COM_SUN_STAR_UNO_XINTERFACE_HPP_
#include <com/sun/star/uno/XInterface.hpp>
#endif

#if ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
static typelib_TypeDescriptionReference * s_pType_com_sun_star_lang_XLocalizable = 0;
#endif

inline const ::com::sun::star::uno::Type& SAL_CALL getCppuType( const ::com::sun::star::uno::Reference< ::com::sun::star::lang::XLocalizable >* ) SAL_THROW( () )
{
    #if ! ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
    static typelib_TypeDescriptionReference * s_pType_com_sun_star_lang_XLocalizable = 0;
    #endif

    if ( !s_pType_com_sun_star_lang_XLocalizable )
    {
        typelib_static_interface_type_init( &s_pType_com_sun_star_lang_XLocalizable, "com.sun.star.lang.XLocalizable", 0 );
    }
    return * reinterpret_cast< ::com::sun::star::uno::Type * >( &s_pType_com_sun_star_lang_XLocalizable );
}

#endif // _COM_SUN_STAR_LANG_XLOCALIZABLE_HPP_
