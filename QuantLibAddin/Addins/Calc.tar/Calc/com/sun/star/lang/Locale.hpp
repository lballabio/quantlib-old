#ifndef _COM_SUN_STAR_LANG_LOCALE_HPP_
#define _COM_SUN_STAR_LANG_LOCALE_HPP_

#ifndef _COM_SUN_STAR_LANG_LOCALE_HDL_
#include <com/sun/star/lang/Locale.hdl>
#endif

#ifndef _OSL_MUTEX_HXX_
#include <osl/mutex.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_TYPE_HXX_
#include <com/sun/star/uno/Type.hxx>
#endif


namespace com
{
namespace sun
{
namespace star
{
namespace lang
{

inline Locale::Locale() SAL_THROW( () )
    : Language()
    , Country()
    , Variant()
{
}

inline Locale::Locale(const ::rtl::OUString& __Language, const ::rtl::OUString& __Country, const ::rtl::OUString& __Variant) SAL_THROW( () )
    : Language(__Language)
    , Country(__Country)
    , Variant(__Variant)
{
}

} // lang
} // star
} // sun
} // com

#if ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
static typelib_TypeDescriptionReference * s_pType_com_sun_star_lang_Locale = 0;
#endif

inline const ::com::sun::star::uno::Type& SAL_CALL getCppuType( const ::com::sun::star::lang::Locale* ) SAL_THROW( () )
{
    #if ! ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
    static typelib_TypeDescriptionReference * s_pType_com_sun_star_lang_Locale = 0;
    #endif

    if ( !s_pType_com_sun_star_lang_Locale )
    {
        typelib_TypeDescriptionReference * aMemberRefs[3];
        const ::com::sun::star::uno::Type& rMemberType_string = getCppuType( ( const ::rtl::OUString *)0 );
        aMemberRefs[0] = rMemberType_string.getTypeLibType();
        aMemberRefs[1] = rMemberType_string.getTypeLibType();
        aMemberRefs[2] = rMemberType_string.getTypeLibType();

        typelib_static_compound_type_init( &s_pType_com_sun_star_lang_Locale, typelib_TypeClass_STRUCT, "com.sun.star.lang.Locale", 0, 3,  aMemberRefs );
    }
    return * reinterpret_cast< const ::com::sun::star::uno::Type * >( &s_pType_com_sun_star_lang_Locale );
}

#endif // _COM_SUN_STAR_LANG_LOCALE_HPP_
