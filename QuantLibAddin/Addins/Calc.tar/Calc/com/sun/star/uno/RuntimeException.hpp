#ifndef _COM_SUN_STAR_UNO_RUNTIMEEXCEPTION_HPP_
#define _COM_SUN_STAR_UNO_RUNTIMEEXCEPTION_HPP_

#ifndef _COM_SUN_STAR_UNO_RUNTIMEEXCEPTION_HDL_
#include <com/sun/star/uno/RuntimeException.hdl>
#endif

#ifndef _OSL_MUTEX_HXX_
#include <osl/mutex.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_TYPE_HXX_
#include <com/sun/star/uno/Type.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_EXCEPTION_HPP_
#include <com/sun/star/uno/Exception.hpp>
#endif

namespace com
{
namespace sun
{
namespace star
{
namespace uno
{

inline RuntimeException::RuntimeException() SAL_THROW( () )
    : ::com::sun::star::uno::Exception()
{ }

inline RuntimeException::RuntimeException(const ::rtl::OUString& __Message, const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& __Context) SAL_THROW( () )
    : ::com::sun::star::uno::Exception(__Message, __Context)
{ }

} // uno
} // star
} // sun
} // com

#if ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
static typelib_TypeDescriptionReference * s_pType_com_sun_star_uno_RuntimeException = 0;
#endif

inline const ::com::sun::star::uno::Type& SAL_CALL getCppuType( const ::com::sun::star::uno::RuntimeException* ) SAL_THROW( () )
{
    #if ! ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
    static typelib_TypeDescriptionReference * s_pType_com_sun_star_uno_RuntimeException = 0;
    #endif

    if ( !s_pType_com_sun_star_uno_RuntimeException )
    {
        typelib_static_compound_type_init( &s_pType_com_sun_star_uno_RuntimeException, typelib_TypeClass_EXCEPTION, "com.sun.star.uno.RuntimeException", * ::typelib_static_type_getByTypeClass( typelib_TypeClass_EXCEPTION ), 0,  0 );
    }
    return * reinterpret_cast< const ::com::sun::star::uno::Type * >( &s_pType_com_sun_star_uno_RuntimeException );
}

#endif // _COM_SUN_STAR_UNO_RUNTIMEEXCEPTION_HPP_
