#ifndef _COM_SUN_STAR_UNO_EXCEPTION_HPP_
#define _COM_SUN_STAR_UNO_EXCEPTION_HPP_

#ifndef _COM_SUN_STAR_UNO_EXCEPTION_HDL_
#include <com/sun/star/uno/Exception.hdl>
#endif

#ifndef _OSL_MUTEX_HXX_
#include <osl/mutex.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_TYPE_HXX_
#include <com/sun/star/uno/Type.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_XINTERFACE_HPP_
#include <com/sun/star/uno/XInterface.hpp>
#endif

namespace com
{
namespace sun
{
namespace star
{
namespace uno
{

inline Exception::Exception() SAL_THROW( () )
    : Message()
    , Context()
{ }

inline Exception::Exception(const ::rtl::OUString& __Message, const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& __Context) SAL_THROW( () )
    : Message(__Message)
    , Context(__Context)
{ }

} // uno
} // star
} // sun
} // com

inline const ::com::sun::star::uno::Type& SAL_CALL getCppuType( const ::com::sun::star::uno::Exception* ) SAL_THROW( () )
{
    return * reinterpret_cast< const ::com::sun::star::uno::Type * >( ::typelib_static_type_getByTypeClass( typelib_TypeClass_EXCEPTION ) );
}

#endif // _COM_SUN_STAR_UNO_EXCEPTION_HPP_
