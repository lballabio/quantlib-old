#ifndef _COM_SUN_STAR_REGISTRY_REGISTRYKEYTYPE_HPP_
#define _COM_SUN_STAR_REGISTRY_REGISTRYKEYTYPE_HPP_

#ifndef _COM_SUN_STAR_REGISTRY_REGISTRYKEYTYPE_HDL_
#include <com/sun/star/registry/RegistryKeyType.hdl>
#endif

#ifndef _OSL_MUTEX_HXX_
#include <osl/mutex.hxx>
#endif

#ifndef _COM_SUN_STAR_UNO_TYPE_HXX_
#include <com/sun/star/uno/Type.hxx>
#endif

#if ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
static typelib_TypeDescriptionReference * s_pType_com_sun_star_registry_RegistryKeyType = 0;
#endif

inline const ::com::sun::star::uno::Type& SAL_CALL getCppuType( const ::com::sun::star::registry::RegistryKeyType* ) SAL_THROW( () )
{
    #if ! ((defined(__SUNPRO_CC) && (__SUNPRO_CC == 0x500)) || (defined(__GNUC__) && defined(__APPLE__)))
    static typelib_TypeDescriptionReference * s_pType_com_sun_star_registry_RegistryKeyType = 0;
    #endif

    if ( !s_pType_com_sun_star_registry_RegistryKeyType )
    {
        typelib_static_enum_type_init( &s_pType_com_sun_star_registry_RegistryKeyType,
                                       "com.sun.star.registry.RegistryKeyType",
                                       ::com::sun::star::registry::RegistryKeyType_KEY );
    }
    return * reinterpret_cast< ::com::sun::star::uno::Type * >( &s_pType_com_sun_star_registry_RegistryKeyType );
}

#endif // _COM_SUN_STAR_REGISTRY_REGISTRYKEYTYPE_HPP_
